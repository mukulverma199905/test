module.exports = {
  apps: [

    {
      name: "App",
      script: "dist/client/app.js",
    },
  ],
};
