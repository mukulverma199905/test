// import redis from "@db/redis";
// import axios from "axios";
// import ioClient from "socket.io-client";

// const projectKey = "RS_P_1767866684191936520";
// const token = "v5sRS_P_1767866684191936520s13048155558828450836";
// const requestData = {
//   method: "web_socket",
// };

// const socketClient = ioClient("http://socket.sports.roanuz.com/cricket", {
//   path: "/v5/websocket",
//   reconnection: true,
// });
// console.log("socketClient: ", socketClient);

// export { socketClient };
