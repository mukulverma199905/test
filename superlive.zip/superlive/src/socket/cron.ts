import redis from "@db/redis";
import requests from "@helpers/odds/requests";
import Agenda, { Job } from "agenda";
import env from "@config/mongo";
import { connectDB } from "@db/mongo";
import Series from "@models/Series";
import Teams from "@models/Teams";
import Squads from "@models/Squads";
import Fixtures from "@models/Fixtures";
import moment from "moment";
import Ads from "@models/Ads";
import Commentary from "@models/Commentary";
import User from "@models/User";
import Session from "@models/Session";
import {
	ScoreFormater,
	ScoreImgFormater,
	getMatchStatus,
	getRemainingTime,
	isTest,
	ordinal_suffix_of,
	shortNameConverter,
} from "@helpers/common";
import { log, removeFile } from "@helpers/logger";

const agenda = new Agenda({
	db: {
		address: env.uri,
		collection: "jobs",
	},
});

agenda.define("save_matches", async (job: Job) => {
	// try {
	// 	console.log("Saving matches START");
	// 	let matches = await requests.getMarketOdds();
	// 	let entries = matches.map((m) => {
	// 		return {
	// 			updateOne: {
	// 				filter: { _id: m?._id },
	// 				update: m,
	// 				upsert: true,
	// 				new: true,
	// 			},
	// 		};
	// 	});
	// 	let data = await Fixtures.bulkWrite(entries);
	// 	console.log("Saving matches END");
	// 	let upsertedFixtures = matches.filter((f) =>
	// 		data
	// 			?.getUpsertedIds()
	// 			?.map((m) => m?._id)
	// 			?.includes(f._id),
	// 	);
	// 	if (upsertedFixtures.length) {
	// 		for (let f of upsertedFixtures) {
	// 			const time = moment(f?.starting_at, "DD-MMM HH:mm A").format();
	// 			let today = moment();
	// 			const past = moment(time).isBefore(today);
	// 			console.log(
	// 				`PAST: ${past}, TIME: ${today.format()}, MATCH TIME: ${
	// 					f?.starting_at
	// 				}`,
	// 			);
	// 			if (past) {
	// 				console.log(`SCHDULED: ${f?._id} --> PAST`);
	// 				await agenda.schedule(
	// 					today.add(2, "seconds").format(),
	// 					"save_commentary",
	// 					{
	// 						fixture_id: f?._id,
	// 						series_id: f?.series_id,
	// 					},
	// 				);
	// 			} else {
	// 				console.log(`SCHDULED: ${f?._id} --> FUTURE`);
	// 				await agenda.schedule(time, "save_commentary", {
	// 					fixture_id: f?._id,
	// 					series_id: f?.series_id,
	// 				});
	// 			}
	// 		}
	// 	}
	// 	return;
	// } catch (err) {
	// 	console.log(err);
	// }
});

agenda.define("save_series", async (job: Job) => {
	try {
		// await log.cron("SAVE SERIES");
		requests.setSource("CRON");
		let series = await requests.getSeries();
		// await log.cron(`${series?.length} SERIES FOUND`);

		if (!series?.length) {
			// await log.cron(`NO SERIES FOUND`);

			const time = moment().add(15, "seconds").format();

			await agenda.schedule(time, "save_series", {});

			// await log.cron(`TRYING AGAIN AFTER 15 SECs \n\n`);

			return false;
		}

		let entries: any = [];

		for (let s of series) {
			await log.cron(`${s?.series} ${s?.series_id}`);

			entries.push({
				updateOne: {
					filter: { _id: s?.series_id },
					update: {
						_id: s?.series_id,
						title: s?.series,
						date: s?.series_date,
						start_date: s?.start_date,
						end_date: s?.end_date,
						total_matches: s?.total_matches,
						month_wise: s?.month_wise,
						// image: s?.image,
					},
					upsert: true,
					new: true,
				},
			});
		}

		let data = await Series.bulkWrite(entries);

		// await log.cron(`ALL SERIES UPDATED`);

		let upsertedSeries = data.getUpsertedIds();

		// await log.cron(`SERIES UPDATED COUNT ${upsertedSeries.length}`);

		if (upsertedSeries.length) {
			let index = -1;
			for (let s of upsertedSeries) {
				index = index + 5;

				const time = moment().add(index, "seconds").format();

				await agenda.schedule(time, "save_teams", {
					series: s._id,
				});

				// await log.cron(
				// 	`SAVE TEAMS SCHEDULED AT ${time}  ${
				// 		upsertedSeries?.at(-1)?._id == s?._id ? "\n\n" : ""
				// 	}`,
				// );
			}
		}

		return true;
	} catch (err) {
		console.log(err);
	}
});

agenda.define("save_fixtures", async (job: Job) => {
	let match_id = job.attrs?.data?.match_id;
	const first = job.attrs?.data?.first;
	let status: any = await redis.get(`matchstatusfortempuse:${match_id}`);
	try {
		// await log.cron(`SAVE FIXTURES  FOR ${match_id}`);
		requests.setSource("CRON");

		let d = await requests.getMatcheDetail(match_id);
		requests.setSource("CRON");

		let info = await requests.getMatcheInfo(match_id);

		if (!status) {
			let today = moment();
			const time = moment(
				`${info?.match_date} ${info?.match_time}`,
				"DD-MMM HH:mm A",
			).format();

			const past = moment(time).isBefore(today);
			console.log("time: ", time);
			console.log("past: ", past);
			// const _time = moment().add(2, "seconds").format();

			// await agenda.schedule(_time, "save_fixtures", {
			// 	match_id: match_id,
			// });
			// await log.cron(
			// 	`SAVE FIXTURE AGAIN SCHEDULED FOR STATUS FOR ${match_id} AT ${_time}`,
			// );
			if (past) {
				status = "COMPLETED";
			} else {
				status = "UPCOMING";
			}
		}

		// await log.cron(`FIXTURES DATA ${d?.match_id} - ${info?.match_id}`);

		let manual: any = await redis.exists("manual_match_update:" + match_id);
		let teamAManualData;
		let teamBManualData;

		if (manual) {
			teamAManualData = await redis.getJson(
				`manual_match_data:${match_id}:${d?.team_a_id}`,
			);

			if (teamAManualData) {
				d["team_a_over"] = `${teamAManualData?.over}.${teamAManualData?.balls}`;
				d[
					"team_a_scores"
				] = `${teamAManualData?.run}-${teamAManualData?.wicket}`;
			}

			teamBManualData = await redis.getJson(
				`manual_match_data:${match_id}:${d?.team_b_id}`,
			);
			if (teamBManualData) {
				d["team_b_over"] = `${teamBManualData?.over}.${teamBManualData?.balls}`;
				d[
					"team_b_scores"
				] = `${teamBManualData?.run}-${teamBManualData?.wicket}`;
			}
		}

		let oddsManual: any = {
			rnb: { update: false },
			over: { update: false },
			ex: { update: false },
			fav2: { update: false },
			draw: { update: false },
			live: {
				update: false,
			},
		};
		let oddsManualData;

		for (let key in oddsManual) {
			const _key = `manual_match_odds_update_${key}:${match_id}`;

			let _oddsManual: any = await redis.exists(_key);
			if (key == "live") {
				_oddsManual = true;
			}

			if (_oddsManual) {
				if (!oddsManualData) {
					const __key = `odds_manual_data:${match_id}:session`;
					oddsManualData = await redis.hgetall(__key);
				}
				// if (d?.match_id == 2731) {
				// 	console.log(key + " " + oddsManualData[key]);
				// }
				//{"url":"","active":true}
				if (oddsManualData) {
					if (!oddsManualData[key] && key == "live") {
						oddsManualData[key] = '{"url":"","active":false}';
					}
					oddsManual[key] = {
						update: true,
						values: JSON.parse(oddsManualData[key] || "{}"),
					};
				}
			}
		}

		let oddsManualUpdateObj = {
			rnb_update: oddsManual.rnb?.update || false,
			over_update: oddsManual.over?.update || false,
			ex_update: oddsManual.ex?.update || false,
		};

		let team =
			parseInt(d?.batting_team) == parseInt(d?.team_a_id)
				? {
						rnb: {
							availableToBack:
								parseFloat(d?.s_ovr) > 0
									? Math.trunc(
											(parseFloat(d?.s_ovr) -
												parseFloat(d?.team_a_over ? d?.team_a_over : 0)) *
												6,
									  )
									: null,
							availableToLay: d?.team_a_scores
								? Math.abs(
										parseFloat(
											d?.team_a_scores
												? d?.team_a_scores?.split("-")?.[0] || 0
												: 0,
										) - parseFloat(d?.s_max),
								  )
								: null,
						},
				  }
				: {
						rnb: {
							availableToBack:
								parseFloat(d?.s_ovr) > 0
									? Math.trunc(
											(parseFloat(d?.s_ovr) -
												parseFloat(d?.team_b_over ? d?.team_b_over : 0)) *
												6,
									  )
									: null,
							availableToLay: d?.team_b_scores
								? Math.abs(
										parseFloat(
											d?.team_b_scores
												? d?.team_b_scores?.split("-")?.[0] || 0
												: 0,
										) - parseFloat(d?.s_max),
								  )
								: null,
						},
				  };

		let obj = {
			_id: d?.match_id,
			team_a_id: d?.team_a_id,
			team_b_id: d?.team_b_id,
			series_id: d?.series_id,
			venue: info?.venue || "",
			umpire: info?.umpire || "",
			third_umpire: info?.third_umpire || "",
			referee: info?.referee || "",
			fav_team: oddsManual.ex?.values?.teamName || d?.fav_team,
			toss: d?.toss,
			result: d?.result,
			match_type: d?.match_type,
			team_a: d?.team_a,
			team_b: d?.team_b,
			current_inning_number: d?.current_inning,
			first_circle: d?.first_circle
				? ScoreFormater(`${d?.first_circle || ""}`)
				: null,
			first_circle_img: d?.first_circle
				? ScoreImgFormater(`${d?.first_circle || ""}`)
				: "",
			second_circle: `${d?.second_circle || ""}`,
			current_inning: `${ordinal_suffix_of(d?.current_inning)} `,
			batsman: d?.batsman,
			bolwer: d?.bolwer,
			batting_team:
				d?.batting_team == d?.team_a_id
					? d?.team_a_short
					: d?.batting_team == d?.team_b_id
					? d?.team_b_short
					: "",
			balling_team:
				d?.balling_team == d?.team_a_id
					? d?.team_a_short
					: d?.balling_team == d?.team_b_id
					? d?.team_b_short
					: "",
			batting_team_score:
				d?.batting_team == d?.team_a_id
					? `${d?.team_a_scores || ""} ${
							d?.team_a_over ? `(${d?.team_a_over})` : " - "
					  }`
					: d?.batting_team == d?.team_b_id
					? `${d?.team_b_scores || ""} ${
							d?.team_b_over ? `(${d?.team_b_over})` : " - "
					  }`
					: "",
			balling_team_score:
				d?.balling_team == d?.team_a_id
					? `${d?.team_a_scores || ""} ${
							d?.team_a_over ? `(${d?.team_a_over})` : " - "
					  }`
					: d?.balling_team == d?.team_b_id
					? `${d?.team_b_scores || ""} ${
							d?.team_b_over ? `(${d?.team_b_over})` : " - "
					  }`
					: "",
			team_a_scores: d?.team_a_scores || "",
			team_a_over: d?.team_a_over,
			team_b_scores: d?.team_b_scores || "",
			team_b_over: d?.team_b_over,
			partnership: d?.partnership,
			curr_rate: d?.curr_rate,
			last4overs: d?.last4overs || [],
			last36ball: d?.last36ball || [],
			target: d?.target,
			rr_rate: d?.rr_rate,
			run_need: d?.run_need,
			ball_rem: d?.ball_rem,
			lastwicket: {
				...d?.lastwicket,
				player: shortNameConverter(d?.lastwicket?.player),
			},
			id: d?.match_id,
			name: `${d?.team_a} vs ${d?.team_b}`,

			competition_name: info?.series,
			teama: d?.team_a,
			teama_image: d?.team_a_img,
			teama_short_name: d?.team_a_short,
			teamb: d?.team_b,
			teamb_image: d?.team_b_img,
			matchs: info?.matchs,
			teamb_id: d?.team_b_id,
			teama_id: d?.team_a_id,
			teamb_short_name: d?.team_b_short,
			format_str: d?.match_type,
			powerplay: d?.powerplay,
			starting_at: `${info?.match_date} ${info?.match_time}`,
			match_datetime: moment(
				`${info?.match_date} ${info?.match_time}`,
				"DD-MMM HH:mm A",
			).format(),
			// remained_time: getRemainingTime(
			// 	moment(
			// 		`${info?.match_date} ${info?.match_time}`,
			// 		"DD-MMM HH:mm A",
			// 	).format(),
			// ),
			ending_at: "2023-02-02 21:30:00",
			status: status,
			status_note: d?.result,
			trail_lead: d?.trail_lead || "",
			live: oddsManual.live?.update
				? oddsManual.live?.values
				: { url: "", active: false },

			ex: oddsManual.ex.update
				? oddsManual.ex?.values
				: {
						back: isTest(d?.match_type)
							? `${d?.max_rate}`
							: d?.max_rate == 0
							? "0"
							: `${
									parseFloat(`${d?.max_rate || 0.0}`.split(".")[1]) * 100
							  }`.slice(0, 2),
						lay: isTest(d?.match_type)
							? `${d?.min_rate}`
							: d?.min_rate == 0
							? "0"
							: `${
									parseFloat(`${d?.min_rate || 0.0}`.split(".")[1]) * 100
							  }`.slice(0, 2),
						teamName: isTest(d?.match_type) ? d?.team_a_short : d?.fav_team,
				  },

			fav2: oddsManual.fav2.update
				? oddsManual.fav2?.values
				: {
						back: isTest(d?.match_type)
							? `${d?.max_rate_1}`
							: d?.max_rate_1 == 0
							? "0"
							: `${
									parseFloat(`${d?.max_rate_1 || 0.0}`.split(".")[1]) * 100
							  }`.slice(0, 2),
						lay: isTest(d?.match_type)
							? `${d?.min_rate_1}`
							: d?.min_rate_1 == 0
							? "0"
							: `${
									parseFloat(`${d?.min_rate_1 || 0.0}`.split(".")[1]) * 100
							  }`.slice(0, 2),
						teamName: d?.team_b_short,
				  },

			draw: oddsManual.draw.update
				? oddsManual.draw?.values
				: {
						back: isTest(d?.match_type)
							? `${d?.max_rate_2}`
							: d?.max_rate_2 == 0
							? "0"
							: `${parseFloat(`${d?.max_rate_2 || 0.0}`)}`,
						lay: isTest(d?.match_type)
							? `${d?.min_rate_2}`
							: d?.min_rate_2 == 0
							? "0"
							: `${parseFloat(`${d?.min_rate_2 || 0.0}`)}`,
						teamName: "DRAW",
				  },

			over: oddsManual.over.update
				? oddsManual.over?.values
				: {
						back: d?.s_max,
						lay: d?.s_min,
						statusText:
							parseFloat(d?.s_ovr) > 0 ? `${d?.s_ovr} Over` : "Over runs",
				  },
			rnb: oddsManual.rnb.update
				? oddsManual.rnb?.values
				: {
						back: !manual ? team.rnb.availableToBack : d.rnb_back,
						lay: !manual ? team.rnb.availableToLay : d.rnb_lay,
				  },
			inning: {
				back: null,
				lay: null,
				statusText: null,
			},
			manual_update: manual,
			yet_to_bet: d?.yet_to_bet || [],
			...oddsManualUpdateObj,
			// scorecard: s,
		};
		const query = {
			_id: match_id,
		};

		let updateOrCreate = await Fixtures.updateOne(query, obj, {
			upsert: true,
			new: true,
		});

		await log.cron(
			`FIXTURE ${match_id} UPDATED : ${updateOrCreate.upsertedCount}`,
		);

		if (updateOrCreate.upsertedCount > 0) {
			const time = moment(obj?.starting_at, "DD-MMM HH:mm A").format();
			let today = moment();

			const past = moment(time).isBefore(today);

			if (past) {
				// await log.cron(
				// 	`OLD MATCH TIME: ${obj?.starting_at} SAVE COMMENTARY SCHEDULED`,
				// );

				await agenda.schedule(
					today.add(2, "seconds").format(),
					"save_commentary",
					{
						fixture_id: obj?._id,
						series_id: obj?.series_id,
					},
				);
			} else {
				await agenda.schedule(time, "save_commentary", {
					fixture_id: obj?._id,
					series_id: obj?.series_id,
				});

				await agenda.schedule(time, "save_fixtures", {
					match_id: match_id,
				});

				await log.cron(
					`FUTURE  MATCH TIME: ${obj?.starting_at} SAVE FIXTURE SCHEDULED at ${time}`,
				);
			}
		}

		if (first) {
			const time = moment().add(2, "seconds").format();

			await agenda.schedule(time, "save_squads", {
				match_id: obj?._id,
				team_a_short: obj?.teama_short_name,
				team_b_short: obj?.teamb_short_name,
				team_a_id: obj?.team_a_id,
				team_b_id: obj?.team_b_id,
				series_id: obj.series_id,
			});

			// await log.cron(`SAVE SQUADS SCHEDULED FOR ${obj?._id} AT ${time} \n\n`);
		}

		if (status == "LIVE") {
			const _time = moment().add(60, "seconds").format();

			await agenda.schedule(_time, "save_fixtures", {
				match_id: match_id,
			});
			await log.cron(
				`MATCH STATUS IS LIVE SO SAVE FIXTURE AGAIN SCHEDULED FOR ${match_id} AT ${_time}`,
			);
		}
	} catch (err) {
		if (status == "LIVE") {
			const _time = moment().add(60, "seconds").format();

			await agenda.schedule(_time, "save_fixtures", {
				match_id: match_id,
			});
			await log.cron(
				`SAVE FIXTURE AGAIN SCHEDULED BY CATH FOR ${match_id} AT ${_time}`,
			);
		}

		return err;
	}
});

agenda.define("save_teams", async (job: Job) => {
	let series = job.attrs?.data?.series;

	// await log.cron(`SAVE TEAMS  FOR ${JSON.stringify(series)}`);
	requests.setSource("CRON");

	let fixtures = await requests.getSeriesDetail(series);
	console.log(`Series Id ${series} `);

	// await log.cron(`SERIES ${series} MATCH COUNT ${fixtures?.length}`);

	if (fixtures?.length) {
		await job.remove();
		let teams: any = [];

		let i = 0;
		let seconds = -1;
		for (let f of fixtures) {
			await log.cron(
				`TEAM ${f?.team_a_short} vs ${f?.team_b_short} - ${f?.match_id}`,
			);
			console.log(
				`TEAM ${f?.team_a_short} vs ${f?.team_b_short} - ${f?.match_id}`,
			);
			i++;

			let fixtureTeams = ["a", "b"].map((t) => {
				return {
					updateOne: {
						filter: { _id: f?.[`team_${t}_id`] },
						update: {
							_id: f?.[`team_${t}_id`],
							name: f?.[`team_${t}`],
							short_name: f?.[`team_${t}_short`],
							flag: f?.[`team_${t}_img`],
						},
						upsert: true,
						new: true,
					},
				};
			});
			// await log.cron(`${i} - TEAMS DATA ${JSON.stringify(fixtureTeams)}`);
			teams = [...teams, ...fixtureTeams];

			// await log.cron(`${i} - TOTAL TEAMS COUNT ${teams?.length}`);
		}
		await Teams.bulkWrite(teams);

		// await log.cron(`TEAMS IN SERIES ${series} ARE ${teams?.length}`);

		let entries = teams.map((t: any) => {
			return {
				updateOne: {
					filter: { _id: series },
					update: {
						$addToSet: {
							teams: t.updateOne.filter._id,
						},
					},
				},
			};
		});

		await Series.bulkWrite(entries);
		// await log.cron(`TEAMS ADDED IN SERIES `);

		for (let f of fixtures) {
			// await log.cron(
			// 	`FIXTURE ${f?.team_a_short} vs ${f?.team_b_short} - ${f?.match_id}`,
			// );
			seconds = seconds + 5;
			const _time = moment().add(seconds, "seconds").format();

			await agenda.schedule(_time, "save_fixtures", {
				match_id: f?.match_id,
				status: f?.save_teams,
				first: true,
			});
			await log.cron(
				`SAVE FIXTURE SCHEDULED FOR ${f?.match_id} AT ${_time} \n\n`,
			);
		}
	} else {
		const time = moment().add(15, "seconds").format();

		await agenda.schedule(time, "save_teams", {
			series: series,
		});

		// await log.cron(`SAVE TEAMS AGAIN SCHEDULED AT ${time} \n\n`);
	}
});

agenda.define("save_squads", async (jobs: Job) => {
	let {
		series_id,
		match_id,
		team_a_short,
		team_b_short,
		team_a_id,
		team_b_id,
	} = jobs.attrs?.data;
	await jobs.remove();
	if (match_id == 2598) {
		console.log(match_id);
	}
	// await log.cron(`SAVE SQUADS FOR ${match_id} ${series_id}`);
	requests.setSource("CRON");

	let squadResponse = await requests.getSquadbyMatchId(match_id);

	// await log.cron(
	// 	`SQUADS DATA ${match_id} ${squadResponse?.team_a?.short_name} ${squadResponse?.team_b?.short_name}`,
	// );

	if (squadResponse) {
		// console.log(`GET SQUADS RUNNING : ${match_id}`);

		let squads: any = [];
		let teamAId =
			squadResponse?.team_a?.short_name == team_a_short ? team_a_id : team_b_id;

		let teamBId =
			squadResponse?.team_b?.short_name == team_b_short ? team_b_id : team_a_id;

		for (let t of squadResponse?.team_a?.player) {
			squads.push({
				updateOne: {
					filter: {
						player_id: t?.player_id,
						match_id: match_id,
						team_id: teamAId,
					},
					update: {
						name: t?.name,
						player_id: `${t?.player_id}`,
						match_id: match_id,
						series_id: series_id,
						team_id: teamAId,
						role: t?.play_role,
						image: t?.image,
					},
					upsert: true,
					new: true,
				},
			});
		}
		for (let t of squadResponse?.team_b?.player) {
			squads.push({
				updateOne: {
					filter: {
						player_id: t?.player_id,
						match_id: match_id,
						team_id: teamBId,
					},
					update: {
						name: t?.name,
						player_id: t?.player_id,
						match_id: match_id,
						series_id: series_id,
						team_id: teamBId,
						role: t?.play_role,
						image: t?.image,
					},
					upsert: true,
					new: true,
				},
			});
		}
		if (squads?.length) {
			await Squads.bulkWrite(squads);
		}
	} else {
		const time = moment().add(15, "minutes").format();

		await agenda.schedule(time, "save_squads", {
			series_id,
			match_id,
			team_a_short,
			team_b_short,
			team_a_id,
			team_b_id,
		});
		// await log.cron(`SAVE SQUADS AGAIN SCHEDULED FOR ${match_id} AT ${time}`);
	}
});

agenda.define("save_commentary", async (jobs: Job) => {
	let { fixture_id, series_id } = jobs.attrs?.data;
	await jobs.remove();
	requests.setSource("CRON");

	let commentaryResponse = await requests.getCommentaryByMatchId(fixture_id);
	if (commentaryResponse && Object.keys(commentaryResponse).length) {
		let collection = [];

		for (let d in commentaryResponse) {
			let overs = commentaryResponse[d];

			for (let o in overs) {
				let over = overs[o] || [];
				let index = 0;
				let schema: any = {
					balls: [],
					fixture_id,
					series_id,
				};
				for (let item of over) {
					if (index == 0) {
						let data = item?.data;
						schema = {
							...schema,
							_id: item?.commentary_id,
							inning: parseInt(item?.inning || 1),
							type: item?.type,
							title: data?.title,
							over: parseInt(data?.over || 0),
							runs: parseInt(data?.runs || 0),
							wickets: parseInt(data?.wickets || 0),
							team: data?.team,
							team_score: parseInt(data?.team_score || 0),
							team_wicket: parseInt(data?.team_wicket || 0),
							batsman_1_name: data?.batsman_1_name,
							batsman_1_runs: parseInt(data?.batsman_1_runs || 0),
							batsman_1_balls: parseInt(data?.batsman_1_balls || 0),
							batsman_2_name: data?.batsman_2_name,
							batsman_2_runs: parseInt(data?.batsman_2_runs || 0),
							batsman_2_balls: parseInt(data?.batsman_2_balls || 0),
							bolwer_name: data?.bolwer_name,
							bolwer_overs: parseInt(data?.bolwer_overs || 0),
							bolwer_maidens: parseInt(data?.bolwer_maidens || 0),
							bolwer_runs: parseInt(data?.bolwer_runs || 0),
							bolwer_wickets: parseInt(data?.bolwer_wickets || 0),
						};
					} else {
						let data = item?.data;
						schema.balls.push({
							_id: item?.commentary_id,
							overs: parseFloat(`${data?.overs}`),
							wicket: parseInt(data?.wicket || 0),
							runs: parseInt(data?.runs || 0),
							title: data?.title,
							description: data?.description,
						});
					}
					index++;
				}
				collection.push({
					updateOne: {
						filter: { _id: schema?._id },
						update: schema,
						upsert: true,
						new: true,
					},
				});
			}
		}

		await Commentary.bulkWrite(collection);

		const time = moment().add(50, "seconds").format();

		await agenda.schedule(time, "save_commentary", {
			fixture_id,
			series_id,
		});
	} else {
		const time = moment().add(50, "seconds").format();

		await agenda.schedule(time, "save_commentary", {
			fixture_id,
			series_id,
		});
	}
});

const main = async () => {
	await connectDB("Cron Thread");
	// await cancelAll();
	await agenda.start();
	await agenda.every("23 hours", "save_series");

	// const time = moment().add(2, "seconds").format();

	// await agenda.schedule(time, "save_series", {});

	// await agenda.every("2 seconds", "save_matches");
};

const cancelAll = async () => {
	await removeFile("cron");
	await removeFile("odds");
	await agenda.cancel({});
	// await redis.flushall();
	// await User.remove();
	// await Session.remove();
	//

	await Series.remove();
	await Teams.remove();
	await Squads.remove();
	await Fixtures.remove();
	await Commentary.remove();
};

setInterval(async () => {
	try {
		requests.setSource("SOCKET");
		let matches = await requests.getMarketOdds();
		await redis.setJson("matched_matches:", matches);
		return;
	} catch (err) {
		console.log(err);
	}
}, 700);

main();
