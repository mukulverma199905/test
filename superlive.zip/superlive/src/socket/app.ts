import keys from "@config/keys";
import { connectDB } from "@db/mongo";
import redis from "@db/redis";
import axios from "axios";

import { ApplyRefCode } from "@helpers/auth";
import { generateRandomUserName, randomInRange } from "@helpers/common";
import FirebaseAdmin from "@helpers/firebase";
import requests from "@helpers/odds/requests";
import { AddUserSession, updateUserSession } from "@helpers/session";
import State from "@models/State";
import User, { User as UserType } from "@models/User";
import { Server, Socket } from "socket.io";
import e from "express";
// import { socketClient } from "./client";

// create socket server
const io = new Server({
  transports: ["websocket", "polling"],
  cors: {
    origin: "*",
  },
});

const fb = new FirebaseAdmin();

// connect to mongodb
connectDB("Socket IO ");

// adding properties to existing socket instance
export interface CustomSocket extends Socket {
  user?: UserType; // or any other type
  isAdminRequest?: boolean;
}

/**
 * User Id Lists
 * @example { ["mongodb objectId"]: "socketId" }
 *
 * getUserById - function to retrieve user's socket id from MongoDB Object Id
 *
 * setUserId - function to set user's socket id with MongoDB Object Id
 */
let userIdList = new Map();

const getUserId = (userId: any) => {
  //   return userIdList.get(`${userId}`) || "";
};

const setUserId = (userId: any, socketId: any) => {
  userIdList.set(`${userId}`, socketId);
};
/* END */

// Interval variable
var interVal: any;

var match_key: any;
var page_key: any;
var match_status: any;
var match_called: any;

// count of connected users
var connectedClients = 0;

/**
 * @Array - userNames
 * Contains all existing usernames
 */
const usersNames = new Set();

const url = "https://rest.cricketapi.com/rest/v2/recent_matches/";
const accessToken = "2s1768856510542254083s13048155279777235966";
let token = "v5sRS_P_1767866684191936520s13048158968143315460";
const projectKey = "RS_P_1767866684191936520";
const requestData = {
  method: "web_socket",
};

var device_id: any;

/**
 * @function sendMessage
 * @param socket
 * @param message
 * @param status
 */
const sendMessage = (socket: CustomSocket, message = "", status = false) => {
  socket.emit("message-request", {
    status: status,
    message: message,
  });
  return true;
};
async function generateToken() {
  try {
    const response = await axios.post(
      "https://api.sports.roanuz.com/v5/core/RS_P_1767866684191936520/auth/",
      {
        api_key: "RS5:bf7a2d2940e94a3d3b362b35bdc8eb89",
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    token = response.data.data.token;
    console.log("token: ", token);

    // Save the token to a file
    // fs.writeFileSync(TOKEN_FILE_PATH, token);

    console.log("Token generated and saved:", token);
  } catch (error) {
    console.log("error: ", error);
  }
}
function scheduleTokenGeneration() {
  //   generateToken(); // Generate token immediately on script startup

  setInterval(generateToken, 12 * 60 * 60 * 1000);
}
async function fetchData(url: any) {
  try {
    const response = await axios.get(url, {
      params: {
        token: token,
      },
    });
    // console.log("response: ", response.data.data);
    return response.data.data;
    //   console.log(response.data);
  } catch (error) {
    console.error("Error:", error);
  }
}

async function fetchPostData(url: any) {
  try {
    const response = await axios.post(url, {
      params: {
        token: token,
      },
    });
    // console.log("response: ", response.data.data);
    return response.data.data;
    //   console.log(response.data);
  } catch (error) {
    console.error("Error:", error);
  }
}
async function subscriptions(match_key: any) {
  try {
    const response = await axios.post(
      `https://api.sports.roanuz.com/v5/cricket/${projectKey}/match/${match_key}/subscribe/`,
      requestData,
      {
        headers: {
          "rs-token": token,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(response.data);
  } catch (error) {
    console.error("Error:", error);
  }
}

function sortByStatus(a: { status: string }, b: { status: string }) {
  const statusOrder: { [key: string]: number } = {
    started: 0,
    not_started: 1,
    completed: 2,
  };
  return statusOrder[a.status] - statusOrder[b.status];
}

// const socketClient = ioClient.connect('http://socket.sports.roanuz.com/cricket', { path: '/v5/websocket', reconnect: true });
// console.log('socketClient: ', socketClient);

// // Add a connect listener
// socketClient.on("connect", function (Socket: any) {
//   console.log("Connected!");
// });
// // prepare required data to access the match data
// var data: any;
// // data.token = rsToken; // token
// data.match_key = "a-rz--cricket--V61769710633282097153"; // match key
// // emit signal to connect to the room
// socketClient.emit("connect_to_match", data);
// // server emits 'on_match_joined'
// socketClient.on("on_match_joined", function (data: any) {
//   console.log("Cricket match joined!", data.key);
// });
// // the subscribed match content are emitted with 'on_match_update' event
// // since it's gzipped data, parse it to unzip it
// socketClient.on("on_match_update", function (res: any) {
//   console.log("data received");
//   console.log(JSON.parse(res));
// });
// // emits 'on_error' on,
// //match not subscribed
// socketClient.on("on_error", function (data: any) {
//   console.log("not_subscribed", JSON.parse(data));
// });
// // socket io connnection
io.on("connection", (socket: CustomSocket) => {
  scheduleTokenGeneration();
  connectedClients++;
  console.log("Socket Connection Received");
  io.emit("secure-data", { activeUsers: connectedClients });
  socket.on("dashboard-request", () => {
    // socket.isAdminRequest = true
    // connectedClients--;
    console.log("dashboard-request");
  });
  // sendMessage(socket, "Connected to Socket Server", true);

  socket.on("set-user", async (d) => {
    device_id = d;
    socket.emit("get-user", d);
    socket.emit("get-token", token);
  });

  //set user data when connected
  // socket.on("set-user", async (d) => {
  //   console.log("set User called");
  //   console.log("d: ", d);

  //   const device_id = d?.device_id;
  //   const user_id = d?.user_id;
  //   const state = d?.state || "";
  //   const fcm_token = d?.fcm_token || "";

  //   // if (!state) {
  //   //   sendMessage(socket, "Please provide a state ", false);
  //   //   return;
  //   // }

  //   if (!device_id) {
  //     sendMessage(socket, "no device ID found", false);
  //   }

  //   let _state;

  //   if (!user_id) {
  //     _state = await State.findOne({
  //       name: {
  //         $regex: new RegExp(state, "i"),
  //       },
  //     }).lean();
  //   } else {
  //     _state = { _id: state };
  //   }

  //   if (!_state) {
  //     sendMessage(socket, "No State available ", false);
  //     _state = await State.findOne({
  //       name: "Out of India",
  //     });
  //     if (!_state) {
  //       _state = await State.create({ name: "Out of India" });
  //     }
  //   }

  //   if (user_id) {
  //     // sendMessage(socket, "User already existed", false);
  //     let existed = await User.countDocuments({ id: user_id });
  //     if (existed) {
  //       if (fcm_token) {
  //         await User.findByIdAndUpdate(user_id, { fcm_token: fcm_token });
  //       }
  //       setUserId(user_id, socket.id);
  //       socket.user = { _id: user_id, state: _state._id } as UserType;
  //       await AddUserSession(user_id, _state._id);
  //       return;
  //     }
  //   }

  //   let username = generateRandomUserName();

  //   const key = "user:username:collection";

  //   while (await redis.sismember(key, username)) {
  //     username = generateRandomUserName();
  //   }

  //   const userKey = "user:userdevice:collection";

  //   let userExist = await redis.sismember(userKey, device_id);

  //   if (fcm_token) {
  //     await redis.sadd(keys.fcmTokens, fcm_token);
  //     fb.subscribeToTopic(fcm_token, keys.topics.global).then();
  //   }

  //   if (userExist) {
  //     // sendMessage(socket, "User already existed", false);
  //     const existedUser = await User.findOne({
  //       device_id: device_id,
  //     });

  //     if (existedUser) {
  //       if (fcm_token) {
  //         await redis.hset(keys.fcmToken, existedUser._id, fcm_token);
  //         existedUser.fcm_token = fcm_token;
  //         await existedUser.save();
  //       }
  //       await redis.hmset(`userData:${existedUser?._id}`, existedUser);

  //       socket.user = existedUser as UserType;
  //       setUserId(existedUser._id.toString(), socket.id);
  //       await AddUserSession(existedUser._id.toString(), _state._id);

  //       socket.emit("get-user", existedUser);
  //     }
  //     return;
  //   }

  //   const avatar = `avatar${randomInRange(1, 29)}.png`;

  //   const ref_code = `${
  //     username.slice(0, 3) + randomInRange(100, 999) + username.slice(-1)
  //   }`.toUpperCase();

  //   const user = await User.create({
  //     username,
  //     ref_code,
  //     device_id,
  //     avatar,
  //     ...(fcm_token && { fcm_token: fcm_token }),
  //     ...(_state && { state: _state._id }),
  //   });

  //   console.log("d?.ref_by: ", d?.ref_by);

  //   await redis.hset(keys.fcmToken, user._id, fcm_token);

  //   if (d?.ref_by) {
  //     await ApplyRefCode(d?.ref_by, user._id);
  //   }

  //   await redis.hincrby(
  //     keys.dashBoardData.key,
  //     keys.dashBoardData.fields.users,
  //     1
  //   );

  //   usersNames.add(username);
  //   await redis.sadd(userKey, device_id);
  //   await redis.sadd(key, username);
  //   await redis.hmset(`userData:${user?._id}`, user.toObject());

  //   socket.user = user;
  //   setUserId(user._id.toString(), socket.id);
  //   await AddUserSession(user._id.toString(), _state._id);

  //   socket.emit("get-user", user);
  // });

  // io.emit("first-event", "hello new user connected");

  socket.on("test-ping", (d) => {
    console.log("test pong sent	");
    io.emit("test-pong", d);
  });
  socket.on("subscriptions", async (d) => {
    const match_id = d.id;
    console.log("match_id: ", match_id);

    const data = await subscriptions(match_id as string);

    var param: any;
    param.token = token; // token
    param.match_key = match_id; // match key
    // socketClient.emit("connect_to_match", data);
    // socketClient.on("on_match_update", function (res: any) {
    //   console.log("data received");
    //   console.log(JSON.parse(res));
    //   socket.emit("subscriptions-done", data);
    // });
  });

  socket.on("recent-matches", async () => {
    console.log("recent-matches called");
    let allMatch = [];
    const oldmatch = await fetchData(
      "https://api.sports.roanuz.com/v5/cricket/" +
        projectKey +
        "/featured-matches-2/"
    );
    // console.log("oldmatch: ", oldmatch.intelligent_order.length);
    if (oldmatch) {
      for (var i = 0; i < oldmatch.intelligent_order.length; i++) {
        var res = await fetchData(
          "https://api.sports.roanuz.com/v5/cricket/" +
            projectKey +
            "/match/" +
            oldmatch.intelligent_order[i] +
            "/"
        );
        allMatch.push(res);
      }

      allMatch.sort(sortByStatus);

      if (allMatch.length === 0) {
        let data = await redis.getJson("all-matches:");
        io.emit("get-all-matches:", data);
        match_called = true;
      } else {
        await redis.setJson("all-matches:", allMatch);
        io.emit("get-all-matches:", allMatch);
        match_called = true;
      }

      // console.log("oldmatch: ", allMatch);
    }
    // if (oldmatch) {
    //   await redis.setJson("recent-matches:", oldmatch);
    // }

    // if (!oldmatch) {
    //   let data = await redis.getJson("recent-matches:");
    //   io.emit("get-recent-matches:", data);
    // } else {
    //   io.emit("get-recent-matches:", oldmatch);
    // }
  });

  socket.on("match-balls", async (data, status) => {
    console.log("match-detail: status-", status);
    if (data) {
      match_key = data;
      match_status = status;
      console.log("match_key: ", match_key);
      await redis.setJson("match_key" + device_id, { data: match_key });
      await redis.setJson("match_status" + device_id, { data: match_status });
      await redis.setJson("page_key" + device_id, { data: page_key });
    }
    let overdetail;
    let balls = [];

    overdetail = await fetchData(
      "https://api.sports.roanuz.com/v5/cricket/" +
        projectKey +
        "/match/" +
        match_key +
        "/ball-by-ball/"
    );
    if (overdetail && match_status == "started") {
      match_called = true;
      socket.emit("get-match-balls", [overdetail.over.balls]);
    } else {
      while (true) {
        if (overdetail.previous_over_key) {
          overdetail = await fetchData(
            "https://api.sports.roanuz.com/v5/cricket/" +
              projectKey +
              "/match/" +
              match_key +
              "/ball-by-ball/" +
              overdetail.previous_over_key +
              "/"
          );
          console.log("resssspose-detai----", overdetail);

          balls.push(overdetail.over.balls);
        } else {
          socket.emit("get-match-balls", balls);
          match_called = true;
          break;
        }
      }
    }
  });

  socket.on("match-overs", async (data) => {
    if (data) {
      match_key = data;
    }
    let overdetail;
    let overs: Map<any, any>[] = [];

    overdetail = await fetchData(
      "https://api.sports.roanuz.com/v5/cricket/" +
        projectKey +
        "/match/" +
        match_key +
        "/over-summary/"
    );
    while (true) {
      if (overdetail.previous_page_key) {
        overdetail = await fetchData(
          "https://api.sports.roanuz.com/v5/cricket/" +
            projectKey +
            "/match/" +
            match_key +
            "/over-summary/" +
            overdetail.previous_page_key +
            "/"
        );
        // console.log("resssspose-detai-Over---", overdetail);
        overdetail.summaries.forEach((item: Map<any, any>) => {
          overs.push(item);
        });
        // overs.push(overdetail.summaries.map((e: Map<String, any>) => e));
      } else if (overs.length === 0) {
        socket.emit("get-match-overs", overdetail.summaries);
        break;
      } else {
        socket.emit("get-match-overs", overs);
        break;
      }
    }
  });
  if (!interVal && match_called) {
    interVal = setInterval(async () => {
      console.log("recent-matches called interval");
      let allMatch = [];
      const oldmatch = await fetchData(
        "https://api.sports.roanuz.com/v5/cricket/" +
          projectKey +
          "/featured-matches-2/"
      );
      // console.log("oldmatch: ", oldmatch.intelligent_order.length);
      if (oldmatch) {
        for (var i = 0; i < oldmatch.intelligent_order.length; i++) {
          var res = await fetchData(
            "https://api.sports.roanuz.com/v5/cricket/" +
              projectKey +
              "/match/" +
              oldmatch.intelligent_order[i] +
              "/"
          );
          allMatch.push(res);
        }

        allMatch.sort(sortByStatus);

        if (allMatch.length === 0) {
          let data = await redis.getJson("all-matches:");
          io.emit("get-all-matches:", data);
        } else {
          await redis.setJson("all-matches:", allMatch);
          io.emit("get-all-matches:", allMatch);
        }

        // console.log("oldmatch: ", allMatch);
      }

      const data = await redis.getJson("match_key" + device_id);
      const match_status = await redis.getJson("match_status" + device_id);

      // console.log("intervel ballss data", data.data);

      if (
        data.data &&
        match_status.data == "started" &&
        match_called === true
      ) {
        let overdetail;

        overdetail = await fetchData(
          "https://api.sports.roanuz.com/v5/cricket/" +
            projectKey +
            "/match/" +
            data.data +
            "/ball-by-ball/"
        );

        // console.log("balls length", overdetail.over.balls);

        if (overdetail) {
          socket.emit("get-match-balls", [overdetail.over.balls]);
        }

        // while (true) {
        //   if (overdetail.previous_over_key) {
        //     overdetail = await fetchData(
        //       "https://api.sports.roanuz.com/v5/cricket/" +
        //         projectKey +
        //         "/match/" +
        //         match_key +
        //         "/ball-by-ball/" +
        //         overdetail.previous_over_key +
        //         "/"
        //     );
        //     console.log("resssspose-detai----", overdetail);

        //     balls.push(overdetail.over.balls);
        //   } else {
        //     io.emit("get-match-balls", balls[0]);
        //     break;
        //   }
        // }
      }
    }, 1000 * 60);
  }

  /*
   * Users' Events
   */

  socket.on("send-odds", async (d) => {
    let app_matches_key = "app_matches:";
    let app_matches = await redis.getJson(app_matches_key);

    if (!app_matches) {
      console.log("No matches found from app");

      await redis.setJson(app_matches_key, d.data);
      await redis.expire(app_matches_key, 60 * 1);
    }
  });

  socket.on("send-vote", async (d) => {
    const {
      match_id,
      team_a_id,
      team_b_id,
      team_c_id,
      voted_team_id,
      device_id,
      actual_vote,
    } = d;
    console.log("d: ", d);

    async function sendVotes() {
      const teamAKey = `{votetag}team_${match_id}:${team_a_id}`;
      const teamBKey = `{votetag}team_${match_id}:${team_b_id}`;
      const teamCKey = `{votetag}team_${match_id}:${team_c_id || "draw"}`;

      let teamAVotes = parseInt((await redis.get(teamAKey)) || "0");
      let teamBVotes = parseInt((await redis.get(teamBKey)) || "0");
      let teamCVotes = parseInt((await redis.get(teamCKey)) || "0");

      let totalVotes = teamAVotes + teamBVotes + teamCVotes;

      console.log(
        `teamAVotes: ${teamAVotes} - teamBVotes: ${teamBVotes} - teamCVotes: ${teamCVotes}`
      );

      let vote = {
        team_a_vote_percent: parseFloat(
          ((teamAVotes * 100) / totalVotes).toFixed(2)
        ),
        team_b_vote_percent: parseFloat(
          ((teamBVotes * 100) / totalVotes).toFixed(2)
        ),
        team_c_vote_percent: parseFloat(
          ((teamCVotes * 100) / totalVotes).toFixed(2)
        ),
        total_vote: totalVotes,
      };

      console.log(JSON.stringify(vote));

      io.emit(`get-votes-${match_id}`, vote);
      return true;
    }

    if (!actual_vote) {
      console.log("Requested for votes data");
      return await sendVotes();
    }
    //
    const votedKey = `{votetag}team:${match_id + "_" + voted_team_id}:voters`;
    console.log(`votedKey: ${votedKey}`);

    const otherKey = `{votetag}team:${match_id}_${
      voted_team_id == team_a_id
        ? team_b_id
        : voted_team_id == team_b_id
        ? team_a_id
        : team_c_id
    }:voters`;
    console.log(`votedKey: ${otherKey}`);

    const drawVotedKey = `{votetag}team:${
      match_id + "_" + voted_team_id == team_a_id
        ? team_b_id
        : voted_team_id == team_b_id
        ? team_a_id
        : team_c_id
    }:voters`;
    console.log(`drawVotedKey: ${drawVotedKey}`);

    //
    const userId = device_id;

    console.log(`userId: ${userId}`);

    //
    let voted = await redis.sismember(votedKey, userId);
    let otherVoted = await redis.sismember(otherKey, userId);
    let drawVoted = await redis.sismember(drawVotedKey, userId);

    console.log(
      `voted: ${voted} - otherVoted: ${otherVoted} - drawVoted: ${drawVoted}`
    );

    //
    if (voted || otherVoted || drawVoted) {
      console.log("Sending vote as you already voted ");
      await sendVotes();
      return;
    } else {
      //
      const VoteCountKey = `{votetag}team_${match_id}:${voted_team_id}`;
      console.log(`VoteCountKey: ${VoteCountKey}`);

      //
      const voteSet = await redis.setnx(VoteCountKey, 0);
      console.log(`voteSet: ${voteSet}`);

      //
      await redis.sadd(votedKey, userId);
      await redis.incr(VoteCountKey);

      return await sendVotes();
    }
  });

  socket.on("get-secure-data", () => {
    io.emit("secure-data", { activeUsers: connectedClients });
  });

  socket.on("disconnect", (history) => {
    // if (!socket?.isAdminRequest) {
    // }
    connectedClients--;

    io.emit("secure-data", { activeUsers: connectedClients });

    if (socket.user?._id) {
      updateUserSession(socket.user?._id, socket.user?.state).then();
    }
    console.log("disconnected", connectedClients);
    if (connectedClients <= 0) {
      clearInterval(interVal);
      interVal = null;
    }
    io.emit("disconnected", "user gone");
  });
});
console.log("trying to start socket io");
io.listen(4009);
console.log("socket io started");
