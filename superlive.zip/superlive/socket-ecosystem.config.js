module.exports = {
  apps: [
    {
      name: "Socket",
      script: "dist/socket/app.js",
    }
  ],
};
