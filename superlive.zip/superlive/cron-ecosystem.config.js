module.exports = {
  apps: [

    {
      name: "Cron",
      script: "dist/socket/cron.js",
    },

  ],
};
