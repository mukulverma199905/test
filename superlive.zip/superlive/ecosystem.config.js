module.exports = {
  apps: [
    {
      name: "Socket",
      script: "dist/socket/app.js",
    },
    {
      name: "App",
      script: "dist/client/app.js",
    },
  ],
};
